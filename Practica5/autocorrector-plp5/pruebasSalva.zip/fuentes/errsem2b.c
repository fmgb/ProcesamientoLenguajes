
int a,b,c;
float p[4][4];

int main()
{
  int i,j;
  i = 24;

  if (i)
  {
    float f[50][50];
    float b[10][500];
  }
  else
  {
    int pene[6000][6000][23];
  }
  while (i<17000)
  {
    int a;
    i=i+1;
  }

}
