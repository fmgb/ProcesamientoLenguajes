
int main()
{
  float f,g[10][4];
  
  g[7][2][1] = 2.5;
}
