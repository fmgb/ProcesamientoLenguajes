
int a,b,c,d,e,f,g,a;

int main() {
;
}
