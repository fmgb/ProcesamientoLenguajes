
int a[5][4][3][2][1][0];

int main() 
{
  ;
}
