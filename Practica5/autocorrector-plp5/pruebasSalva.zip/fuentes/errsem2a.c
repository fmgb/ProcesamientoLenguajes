
int a,b,c;
float d[30][40];
int main()
{
  float a,b;
  
  a = 7.5;
  c = a;
  scanf("%d",&d[20][20]);
  printf("%g",d[20][20]);
  if (c > 7.1)
  {
    int a,b,h;
    a = c+3*(10/9);
    b = a/2/2;
    printf("%d",b);
  }

  if(a == 7.5)
  {
    float d, g;

    h = 20;
    /error/
    g = 30.245 / a;
  }
  printf("%g",a);
  printf("%d",c);
}
