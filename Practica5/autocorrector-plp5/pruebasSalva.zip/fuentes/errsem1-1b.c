
int a,b,c;
float a;
int main()
{
  float a,b;
  
  a = 7.5;
  c = a;
  if (c > 7.1)
  {
    int a,b;
    
    a = c+3*(10/9);
    b = a/2/2;
    printf("%d",b);
  }
  printf("%g",a);
  printf("%d",c);
}
