
int a,b,C;

int main() {

 a = 7;
 c = a;
 printf("%d",c);
}
