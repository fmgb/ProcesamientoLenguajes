
int a,b,c,d,e,f,g,a[30][30][4000];

int main() {
;
}
