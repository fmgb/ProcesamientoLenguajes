
int i,j,k;
int a[100][200][300];

int main() 
{
  i=8;
  j=9;
  printf("%d",j);
}
